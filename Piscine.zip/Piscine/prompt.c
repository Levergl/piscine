/*
** prompt.c for prompt in /home/leverg_l/battle_for_Midgard
** 
** Made by LEVERGEOIS Livien
** Login   <leverg_l@etna-alternance.net>
** 
** Started on  Fri Oct 31 18:49:22 2014 LEVERGEOIS Livien
** Last update Fri Oct 31 19:11:10 2014 LEVERGEOIS Livien
*/
int	prompt(int argc, char *argv[])
{
  my_putstr("Your turn > ");
  readLine();
  return (0);
}

