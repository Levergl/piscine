void	run_game();
{
  check_name(ac, av);
  clear(ac, av);
  
  
